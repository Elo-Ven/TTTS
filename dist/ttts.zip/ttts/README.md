# TTTS - Twine Text To Speech

Version: 2.1.0

Licence: Creative Common Attribution 4.0 International \
https://creativecommons.org/licenses/by/4.0/

## Summary

If you are that sort of person that prefers listening to audiobooks over reading books, this mod will make Twine story games much more enjoyable for you.

Your web browser already has text-to-speech tools built into it right now. Your Twine game just isn't using them. This mod add a small control panel where you can play the story text in the game via those built-in tools.

The mod can also be added to a Twine game by anyone, dev or player.

## Installation

### 1 - Download

Download the zip file with the latest version from the project GitHub page \
https://github.com/Elo-Ven/TTTS/raw/main/dist/ttts.zip

### 2 - Locate

Find the game directory for the game you want to mod. This is the folder where the .html file is that you use to run the game.

### 3 - Unpack

Copy the 'ttts' directory into the game directory, next to the games .html. (see the demo for confirmation) \
https://github.com/Elo-Ven/TTTS/tree/main/demo

### 4 - Import

Import using either the automatic or manual method

#### 4A - Automatic Import (recommended)

Run `install.bat` and when asked, enter the filename of your games main html file (e.g. `mygame.html`). A copy of that file will be created (`mygame-mod.html`). Run the game using the newly created file to run it with TTTS.

#### 4B - Manual Import

Alternatively, you can manually import TTTS.

Open your games `mygame.html` file in a suitable text editor such as Notepad++ and navigate to the very end of the file (there maybe a delay depending on the size of the html file).

Copy this line of code

```
<script src="ttts/ttts-config.js"></script>
```

And paste it just before the `</body>` tag in the html file you just opened

```
    </script>
	<script src="ttts/ttts.js"></script>
</body>
</html>
```

## Default Options

| Option Name | Type    | Default              | Description                                                                                                    |
| ----------- | ------- | -------------------- | -------------------------------------------------------------------------------------------------------------- |
| ignores     | array   | `['.link-internal']` | list of css style selectors for elements that should not be included in the play queue                         |
| pitch       | float   | `1`                  | value is passed directly to SpeechSynthesisUtterance.pitch                                                     |
| rate        | float   | `1`                  | value is passed directly to SpeechSynthesisUtterance.rate                                                      |
| trigger     | array   | `['.link-internal']` | list of css style selectors for elements that should trigger TTTS to autoplay (e.g. passage navigation)        |
| voice       | integer | `0`                  | the array key of the active SpeechSynthesisUtterance voice. full array in `window.speechSynthesis.getVoices()` |
| volume      | float   | `1`                  | value is passed directly to SpeechSynthesisUtterance.volume                                                    |

### Overriding Default Params

Open `ttts-config.js` in a suitable text editor and then remove the // from the stat of the line to enable an option. Then change the value to have it always applied. This tool is primarily intended for sharing settings profiles across games.

Please note that if you change the option in-game, using the TTTS settings popup, that value will be used instead of the value in `ttts-config.js`

```
var tttsConfig = {
    //pitch: 1,
    //rate: 1.0,
    //silence: ['.link-internal'],
    //trigger: ['.link-internal'],
    //voice: 0,
    //volume: 1,
};
```

### How To Silence Non-Story Text

Some games have additional menus and navigation that we would rather are not read every time a passage loads.

We can exclude them from being spoken using the `silence` option. Use your web browsers 'Element Inspector' to find the id or class name of an element that encloses the text you want to exclude. Add a JS selector to the silence array in `ttts-config.js` and then refresh the page.

This method isn't always possible, it depends a lot on the game and what you want to `silence`. It also requires some basic knowledge of html so if you create a config file, please share it online with the rest of community so that they can download it and replace their copy with the improved version for that game.

## FAQ (a.k.a what i think you might have questions about)

### Compatibility

#### System

Tested and working on Windows. Not tested on Mac but I can't think of a major reason why it wouldn't work.

#### Twine

Tested and working with Sugarcube and Harlowe based games.

### Its acting weird

Yeah... depending on how the game dev has set up their passages it's really difficult to predict what text structure or names will be used. The `trigger` and `silence` options can help or completely fix issues, but sometimes you just have to put up with some inconvenience, soz...

## Thank You For Reading

"It doesn't stop being magic just because you know how it works." - Terry Pratchett / The Wee Free Men
